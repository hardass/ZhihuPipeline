import asyncio
import click
from loguru import logger

from zhihu_pipeline.config import load_config
from zhihu_pipeline.sync_engine import SyncEngine

@click.group()
def cli():
    """Zhihu collections to Obsidian Vault Sync Pipeline."""
    pass

@cli.command()
@click.option("--full", is_flag=True, help="Full sync, ignoring previous sync history.")
@click.option("--collection", default=None, help="Sync only a specific collection by title.")
def sync(full, collection):
    """Synchronize collections with the local Obsidian Vault."""
    config = load_config()
    engine = SyncEngine(config)
    
    # Run sync process
    asyncio.run(engine.run(full_sync=full, target_collection=collection))

@cli.command()
def status():
    """Show current sync stats from the manifest.json."""
    config = load_config()
    engine = SyncEngine(config)
    engine.show_status()

@cli.command("check-auth")
def check_auth():
    """Check connectivity and Zhihu login state."""
    config = load_config()
    engine = SyncEngine(config)
    asyncio.run(engine.check_auth())

@cli.command()
@click.option("--dry-run", is_flag=True, help="Only display pending files without invoking LM Studio.")
@click.option("--force", is_flag=True, help="Reprocess all files, including those already marked as tagged.")
def tag(dry_run, force):
    """
    Run auto-tagging for all untagged (pending/failed) articles.
    Can be run independently, fully decoupled from the sync command.
    """
    config = load_config()
    if not config.tagger.enabled:
        logger.warning("tagger.enabled is false. Please enable it in config.yaml first.")
        return

    from zhihu_pipeline.storage import ManifestManager
    from zhihu_pipeline.tagger import run_tagging_pass
    import os
    manifest_path = os.path.join(
        config.output.vault_path, config.output.collection_dir, "manifest.json"
    )
    manifest = ManifestManager(manifest_path)

    if force:
        # Reset all tagged status to pending
        for key, item in manifest.data.get("synced_items", {}).items():
            if item.get("tagging_status") == "tagged":
                item["tagging_status"] = "pending"
        manifest.save()
        logger.info("--force: Reset all 'tagged' records to 'pending'.")

    pending = manifest.get_untagged_items()
    logger.info(f"Found {len(pending)} articles pending for tagging.")

    if dry_run:
        for key, item in pending:
            print(f"  [pending] {item.get('title', key)}  ({item.get('local_path', '')})")
        return

    success, fail = run_tagging_pass(manifest, config.output.vault_path, config.tagger)
    logger.info(f"Tagging complete: {success} successful, {fail} failed.")
    if fail > 0:
        logger.info("Failed articles have been marked as 'failed' and will be retried next time the 'tag' command is run.")

@cli.command("clear-archive")
@click.option("--collection", default="archive", help="Collection title or numeric ID to clear (defaults to 'archive').")
def clear_archive(collection):
    """Batch remove all items from a Zhihu collection (defaults to 'archive')."""
    config = load_config()
    engine = SyncEngine(config)

    async def _run():
        context = await engine.get_browser_context()
        try:
            from zhihu_pipeline.auth import get_or_create_page, check_login
            page = await get_or_create_page(context)
            logged_in, username = await check_login(page)
            if not logged_in:
                logger.error("You must be logged in to Zhihu to clear collection contents.")
                return

            from zhihu_pipeline.cleaner import delete_collection
            result = await delete_collection(page, target_name_or_id=collection)
            print(f"\n=== 操作完成 ===")
            print(f"状态: {result.get('status')}")
            print(f"目标收藏夹: {result.get('collection_title')} (ID: {result.get('collection_id', 'N/A')})\n")
        finally:
            await context.close()

@cli.command()
def bot():
    """Run interactive Telegram Bot daemon (long-polling mode)."""
    from zhihu_pipeline.bot import TelegramBotDaemon
    config = load_config()
    daemon = TelegramBotDaemon(config)
    
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    try:
        loop.run_until_complete(daemon.run_polling())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot daemon interrupted by user.")
    finally:
        daemon.stop()
        loop.close()

if __name__ == "__main__":
    cli()

